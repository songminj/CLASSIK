-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: k11a604.p.ssafy.io    Database: 604db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PlaylistTrack`
--

DROP TABLE IF EXISTS `PlaylistTrack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PlaylistTrack` (
  `playlist_track_id` int NOT NULL AUTO_INCREMENT,
  `playlist_id` int NOT NULL,
  `track_id` int NOT NULL,
  PRIMARY KEY (`playlist_track_id`),
  KEY `FKgbbftfaj9akidw1orqybvyi1a` (`playlist_id`),
  KEY `FKofw8kjf61ccf7hs5um30npiva` (`track_id`),
  CONSTRAINT `FKgbbftfaj9akidw1orqybvyi1a` FOREIGN KEY (`playlist_id`) REFERENCES `Playlist` (`playlist_id`),
  CONSTRAINT `FKofw8kjf61ccf7hs5um30npiva` FOREIGN KEY (`track_id`) REFERENCES `Track` (`track_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PlaylistTrack`
--

LOCK TABLES `PlaylistTrack` WRITE;
/*!40000 ALTER TABLE `PlaylistTrack` DISABLE KEYS */;
INSERT INTO `PlaylistTrack` VALUES (4,2,1),(5,2,2),(6,2,3),(7,2,4),(8,2,5),(10,3,1),(11,3,1),(12,3,1),(13,3,1),(14,3,1),(16,3,1),(21,5,4),(22,7,5),(23,6,15),(24,6,3),(25,5,16),(26,5,3),(27,8,26),(28,8,134),(29,8,133),(30,9,18),(31,9,32),(32,10,18);
/*!40000 ALTER TABLE `PlaylistTrack` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-19 10:52:40
